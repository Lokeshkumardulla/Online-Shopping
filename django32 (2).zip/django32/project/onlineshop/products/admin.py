from django.contrib import admin
from .models import Product,category


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('prodno', 'prdname', 'category', 'price', 'stock')
    list_filter = ('category',)
    search_fields = ('prdname',)


@admin.register(category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('catid', 'catname')
    search_fields = ('catname',)
