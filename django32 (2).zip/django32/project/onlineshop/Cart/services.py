from decimal import Decimal

from Cart.models import Cart, CartItems
from orders.models import DELIVERY_CHARGE


def get_cart_summary(user):
    cart = Cart.objects.filter(user=user).first()
    items = list(
        CartItems.objects.filter(cart=cart, product__isnull=False)
        .select_related('product')
        if cart else CartItems.objects.none()
    )
    subtotal = sum(
        (item.product.price * item.qty for item in items),
        Decimal('0.00'),
    )
    for item in items:
        item.total_price = item.product.price * item.qty

    delivery_charge = DELIVERY_CHARGE if items else Decimal('0.00')
    return {
        'cart_items': items,
        'subtotal': subtotal,
        'delivery_charge': delivery_charge,
        'grand_total': subtotal + delivery_charge,
    }
