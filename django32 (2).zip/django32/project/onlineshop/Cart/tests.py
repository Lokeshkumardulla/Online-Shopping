from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .models import CartItems
from products.models import Product


class CartFlowTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username='shopper',
            password='test-password',
        )
        self.product = Product.objects.create(
            prodno=20,
            prdname='Desk lamp',
            price='19.95',
            stock=3,
        )
        self.client.force_login(self.user)

    def test_adding_same_product_combines_quantities(self):
        url = reverse('addcarturl', args=[self.product.prodno])

        self.client.post(url, {'qty': '1'})
        self.client.post(url, {'qty': '2'})

        item = CartItems.objects.get(cart__user=self.user, product=self.product)
        self.assertEqual(item.qty, 3)

    def test_add_rejects_quantity_above_stock(self):
        response = self.client.post(
            reverse('addcarturl', args=[self.product.prodno]),
            {'qty': '4'},
            follow=True,
        )

        self.assertEqual(response.status_code, 200)
        self.assertFalse(CartItems.objects.filter(cart__user=self.user).exists())
        self.assertContains(response, 'Only 3 item(s) are currently in stock.')

    def test_remove_requires_post(self):
        self.client.post(reverse('addcarturl', args=[self.product.prodno]), {'qty': '1'})
        item = CartItems.objects.get(cart__user=self.user, product=self.product)

        response = self.client.get(reverse('remove_from_cart', args=[item.cartitemno]))

        self.assertEqual(response.status_code, 405)
        self.assertTrue(CartItems.objects.filter(pk=item.pk).exists())
