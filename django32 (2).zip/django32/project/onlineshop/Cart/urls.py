from django.urls import path
from . import views

urlpatterns = [
    path('add-Cart/<int:pk>/', views.addtocart, name='addcarturl'),
    path('view-cart/', views.viewcart, name='viewcarturl'),
    path('update-cart/<int:item_id>/', views.update_cart, name='update_cart'),
    path('remove-cart/<int:item_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('checkout/', views.checkout, name='checkout'),
]