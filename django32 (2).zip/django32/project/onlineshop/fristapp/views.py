from django.shortcuts import render
from django.http import HttpResponse, HttpResponseNotAllowed

# Create your views here.

def display(request):
    obj = HttpResponse("Hello, World!")
    return obj

def show(request):
    obj = HttpResponse("we are learning django")
    return obj


def calculator(request):
    if request.method == 'POST':
        print(request.POST)
        try:
            v1 = int(request.POST['t1'])
            v2 = int(request.POST['t2'])
        except (KeyError, ValueError):
            return HttpResponse('Enter valid numbers.', status=400)

        if 'add' in request.POST:
            result = v1 + v2
            action = 'Addition'
        elif 'subs' in request.POST:
            result = v1 - v2
            action = 'Subtraction'
        elif 'multi' in request.POST:
            result = v1 * v2
            action = 'Multiplication'
        elif 'div' in request.POST:
            if v2 == 0:
                result = 'Cannot divide by zero.'
            else:
                result = v1 / v2
            action = 'Division'
        else:
            return HttpResponse('Select an operation.', status=400)

        return render(request, 'fristapp/calculator.html', {'result': result, 'action': action})

    if request.method == 'GET':
        return render(request, 'fristapp/calculator.html', {'result': '', 'action': ''})

def mtable(request):
    if request.method == 'GET':
        return render(request, 'fristapp/mtable.html')
    if request.method == 'POST':
        try:
            num = int(request.POST.get('number', ''))
        except ValueError:
            return render(
                request,
                'fristapp/mtable.html', 
                {'error': 'Enter a valid whole number.'},
                status=400,
            )

        output = []
        for i in range(1, 11):
            output.append(str(num) + " x " + str(i) + " = " + str(num * i))

        return render(request, 'fristapp/mtable.html', {'output': output})

    return HttpResponseNotAllowed(['GET', 'POST'])
