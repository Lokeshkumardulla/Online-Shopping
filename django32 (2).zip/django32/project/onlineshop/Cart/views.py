
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import IntegrityError, transaction
from django.http import HttpResponseNotAllowed
from django.shortcuts import get_object_or_404, redirect, render
from .models import Cart, CartItems
from .services import get_cart_summary
from products.models import Product


def addtocart(request, pk):
    if not request.user.is_authenticated:
        return redirect('loginurl')

    if request.method != 'POST':
        return HttpResponseNotAllowed(['POST'])

    try:
        quantity = int(request.POST.get('qty', 1))
    except (TypeError, ValueError):
        messages.error(request, 'Enter a valid quantity.')
        return redirect('detailurl', pk=pk)

    if quantity < 1:
        messages.error(request, 'Quantity must be at least one.')
        return redirect('detailurl', pk=pk)
    try:
        with transaction.atomic():
            cart, _ = Cart.objects.get_or_create(user=request.user)
            cart = Cart.objects.select_for_update().get(pk=cart.pk)
            product = get_object_or_404(
                Product.objects.select_for_update(),
                prodno=pk,
            )
            if quantity > product.stock:
                messages.error(
                    request,
                    'Only {} item(s) are currently in stock.'.format(product.stock),
                )
                return redirect('detailurl', pk=product.prodno)

            item, created = CartItems.objects.get_or_create(
                cart=cart,
                product=product,
                defaults={'qty': quantity},
            )
            if not created:
                new_quantity = item.qty + quantity
                if new_quantity > product.stock:
                    messages.error(request, 'There are not enough items in stock.')
                    return redirect('viewcarturl')
                item.qty = new_quantity
                item.save(update_fields=['qty'])
    except IntegrityError:
        messages.error(request, 'Your cart changed while adding this item. Please try again.')
        return redirect('viewcarturl')

    messages.success(request, 'Added to your cart.')
    return redirect('viewcarturl')


@login_required(login_url='loginurl')
def viewcart(request):
    return render(request, 'cart/cart.html', get_cart_summary(request.user))


@login_required(login_url='loginurl')
def update_cart(request, item_id):
    if request.method != 'POST':
        return HttpResponseNotAllowed(['POST'])

    item = get_object_or_404(
        CartItems.objects.select_related('product'),
        cartitemno=item_id,
        cart__user=request.user,
    )
    try:
        quantity = int(request.POST.get('quantity', ''))
    except (TypeError, ValueError):
        messages.error(request, 'Enter a valid quantity.')
        return redirect('viewcarturl')

    if quantity < 1:
        messages.error(request, 'Quantity must be at least one.')
    elif item.product is None or quantity > item.product.stock:
        messages.error(request, 'There are not enough items in stock.')
    else:
        item.qty = quantity
        item.save(update_fields=['qty'])
        messages.success(request, 'Cart updated.')
    return redirect('viewcarturl')


@login_required(login_url='loginurl')
def remove_from_cart(request, item_id):
    if request.method != 'POST':
        return HttpResponseNotAllowed(['POST'])

    item = get_object_or_404(
        CartItems,
        cartitemno=item_id,
        cart__user=request.user,
    )
    item.delete()
    messages.success(request, 'Item removed from your cart.')
    return redirect('viewcarturl')


def checkout(request):
    if not request.user.is_authenticated:
        return redirect('loginurl')
    return redirect('order_checkout')
