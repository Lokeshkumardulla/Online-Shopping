from decimal import Decimal

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render
from django.views import View

from Cart.models import Cart, CartItems
from Cart.services import get_cart_summary
from products.models import Product
from .forms import CheckoutForm
from .models import DELIVERY_CHARGE, Order, OrderItem


class EmptyCart(Exception):
    pass


class OutOfStock(Exception):
    pass


class CheckoutView(LoginRequiredMixin, View):
    login_url = 'loginurl'

    def _cart_context(self, user):
        return get_cart_summary(user)

    def get(self, request):
        context = self._cart_context(request.user)
        if not context['cart_items']:
            messages.info(request, 'Add an item to your cart before checking out.')
            return redirect('viewcarturl')
        context['form'] = CheckoutForm()
        return render(request, 'orders/checkout.html', context)

    def post(self, request):
        form = CheckoutForm(request.POST)
        if not form.is_valid():
            context = self._cart_context(request.user)
            if not context['cart_items']:
                messages.info(request, 'Add an item to your cart before checking out.')
                return redirect('viewcarturl')
            context['form'] = form
            return render(request, 'orders/checkout.html', context)

        try:
            with transaction.atomic():
                cart = Cart.objects.select_for_update().filter(user=request.user).first()
                if cart is None:
                    raise EmptyCart

                cart_items = list(
                    CartItems.objects.select_for_update()
                    .filter(cart=cart, product__isnull=False)
                    .select_related('product')
                )
                if not cart_items:
                    raise EmptyCart

                product_ids = [item.product_id for item in cart_items]
                locked_products = {
                    product.pk: product
                    for product in Product.objects.select_for_update().filter(
                        pk__in=product_ids
                    )
                }

                order_lines = []
                subtotal = Decimal('0.00')
                for item in cart_items:
                    product = locked_products.get(item.product_id)
                    if product is None or item.qty < 1 or product.stock < item.qty:
                        raise OutOfStock
                    amount = product.price * item.qty
                    subtotal += amount
                    order_lines.append((item, product, amount))

                order = Order.objects.create(
                    user=request.user,
                    shipping_name=form.cleaned_data['shipping_name'],
                    shipping_phone=form.cleaned_data['shipping_phone'],
                    shipping_address=form.cleaned_data['shipping_address'],
                    delivery_charge=DELIVERY_CHARGE,
                    total_amount=subtotal + DELIVERY_CHARGE,
                )

                OrderItem.objects.bulk_create([
                    OrderItem(
                        order=order,
                        product=product,
                        product_name=product.prdname,
                        quantity=item.qty,
                        unit_price=product.price,
                        amount=amount,
                    )
                    for item, product, amount in order_lines
                ])

                quantities_by_product = {}
                for item, product, _ in order_lines:
                    quantities_by_product[product.pk] = (
                        quantities_by_product.get(product.pk, 0) + item.qty
                    )

                for product_id, quantity in quantities_by_product.items():
                    product = locked_products[product_id]
                    product.stock -= quantity
                    product.save(update_fields=['stock'])

                CartItems.objects.filter(pk__in=[item.pk for item in cart_items]).delete()
        except EmptyCart:
            messages.info(request, 'Your cart is empty.')
            return redirect('viewcarturl')
        except OutOfStock:
            messages.error(
                request,
                'One or more items no longer have enough stock. Please review your cart.',
            )
            return redirect('viewcarturl')

        return redirect('order_confirmation', pk=order.pk)


def order_confirmation(request, pk):
    if not request.user.is_authenticated:
        return redirect('loginurl')
    order = get_object_or_404(
        Order.objects.prefetch_related('items'),
        orderno=pk,
        user=request.user,
    )
    return render(request, 'orders/confirmation.html', {'order': order})