from django.db import models
from django.core.validators import MinValueValidator


class category(models.Model):
    catid = models.IntegerField(primary_key=True)
    catname = models.CharField(max_length=100)

    def __str__(self):
        return self.catname


class Product(models.Model):
    prodno = models.IntegerField(primary_key=True)
    prdname = models.CharField(max_length=200)
    price = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        validators=[MinValueValidator(0)],
    )
    stock = models.PositiveIntegerField(default=0)
    category = models.ForeignKey(
        category,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='products',
    )
    picture = models.ImageField(upload_to='images/', null=True, blank=True)

    def __str__(self):
        return self.prdname
