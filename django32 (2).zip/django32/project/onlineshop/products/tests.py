from django.test import TestCase
from django.urls import reverse
from .models import Product, category


class DetailPageTests(TestCase):
    def setUp(self):
        self.product = Product.objects.create(
            prodno=1,
            prdname='Test product',
            price=100,
            stock=5,
            picture='images/test.jpg',
        )

    def test_get_displays_product_detail(self):
        response = self.client.get(
            reverse('detailurl', args=[self.product.prodno])
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, '/media/images/test.jpg')
        self.assertContains(response, 'Test product')
        self.assertContains(response, '100')

    def test_post_is_not_allowed(self):
        response = self.client.post(
            reverse('detailurl', args=[self.product.prodno])
        )

        self.assertEqual(response.status_code, 405)

    def test_missing_product_returns_404(self):
        response = self.client.get(reverse('detailurl', args=[999]))

        self.assertEqual(response.status_code, 404)

    def test_detail_without_image_renders_without_placeholder_text(self):
        product = Product.objects.create(
            prodno=2,
            prdname='No image product',
            price=50,
            stock=0,
        )

        response = self.client.get(reverse('detailurl', args=[product.prodno]))

        self.assertEqual(response.status_code, 200)
        self.assertNotContains(response, 'Image not available')


class HomePageTests(TestCase):
    def test_product_image_and_card_link_to_detail(self):
        product = Product.objects.create(
            prodno=3,
            prdname='Test product',
            price=100,
            stock=5,
            picture='images/test.jpg',
        )

        response = self.client.get(reverse('homeurl'))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'src="/media/images/test.jpg"')
        self.assertContains(response, f'href="/products/detail/{product.prodno}/"')
        self.assertContains(response, 'alt="Test product"')

    def test_homepage_groups_products_under_category_and_keeps_uncategorized(self):
        electronics = category.objects.create(catid=1, catname='Electronics')
        appliances = category.objects.create(catid=2, catname='Appliances')
        Product.objects.create(
            prodno=4,
            prdname='Phone',
            price=500,
            stock=2,
            category=electronics,
        )
        Product.objects.create(
            prodno=5,
            prdname='Toaster',
            price=80,
            stock=1,
            category=appliances,
        )
        Product.objects.create(
            prodno=6,
            prdname='Gift card',
            price=25,
            stock=10,
        )

        response = self.client.get(reverse('homeurl'))
        content = response.content.decode()

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Electronics')
        self.assertContains(response, 'Appliances')
        self.assertContains(response, 'Other products')
        self.assertLess(content.index('Electronics'), content.index('Phone'))
        self.assertLess(content.index('Appliances'), content.index('Toaster'))
        self.assertLess(content.index('Other products'), content.index('Gift card'))
