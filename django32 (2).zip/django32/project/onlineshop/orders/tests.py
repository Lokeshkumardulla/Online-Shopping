from decimal import Decimal

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from Cart.models import Cart, CartItems
from products.models import Product
from .models import Order, OrderItem


class CheckoutTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username='buyer',
            password='test-password',
        )
        self.product = Product.objects.create(
            prodno=30,
            prdname='Coffee maker',
            price='125.50',
            stock=4,
        )
        self.cart = Cart.objects.create(user=self.user)
        CartItems.objects.create(cart=self.cart, product=self.product, qty=2)
        self.client.force_login(self.user)

    def test_checkout_page_shows_delivery_form_and_order_total(self):
        response = self.client.get(reverse('order_checkout'))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Delivery details')
        self.assertContains(response, '₹301.00')

    def test_checkout_creates_order_snapshots_and_decreases_stock(self):
        response = self.client.post(
            reverse('order_checkout'),
            {
                'shipping_name': 'Test Buyer',
                'shipping_phone': '55512345',
                'shipping_address': '10 Test Street',
            },
        )

        order = Order.objects.get(user=self.user)
        item = OrderItem.objects.get(order=order)
        self.assertRedirects(
            response,
            reverse('order_confirmation', args=[order.orderno]),
        )
        self.assertEqual(order.total_amount, Decimal('301.00'))
        self.assertEqual(item.product_name, 'Coffee maker')
        self.assertEqual(item.unit_price, Decimal('125.50'))
        self.assertEqual(item.amount, Decimal('251.00'))
        self.product.refresh_from_db()
        self.assertEqual(self.product.stock, 2)
        self.assertFalse(CartItems.objects.filter(cart=self.cart).exists())
        confirmation = self.client.get(
            reverse('order_confirmation', args=[order.orderno])
        )
        self.assertContains(confirmation, 'Order received')
        self.assertContains(confirmation, 'Coffee maker')

    def test_checkout_does_not_create_order_when_stock_is_insufficient(self):
        self.product.stock = 1
        self.product.save(update_fields=['stock'])

        response = self.client.post(
            reverse('order_checkout'),
            {
                'shipping_name': 'Test Buyer',
                'shipping_phone': '55512345',
                'shipping_address': '10 Test Street',
            },
            follow=True,
        )

        self.assertEqual(response.status_code, 200)
        self.assertFalse(Order.objects.filter(user=self.user).exists())
        self.assertTrue(CartItems.objects.filter(cart=self.cart).exists())
        self.assertContains(response, 'no longer have enough stock')
