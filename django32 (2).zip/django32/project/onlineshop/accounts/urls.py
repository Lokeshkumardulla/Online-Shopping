from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.registeruser, name='registerurl'),
    path('login/', views.loginuser, name='loginurl'),
    path('logout/', views.logoutuser, name='logouturl'),
]