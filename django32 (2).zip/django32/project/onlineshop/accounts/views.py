from django.shortcuts import render,redirect
from django.http import HttpResponse
from .form import LoginForm, RegisterForm
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout

# Create your views here.
def registeruser(request):
    if request.method == 'GET':
        empty_form = RegisterForm()
        return render(request, 'accounts/register.html', {'form': empty_form})
    if request.method == 'POST':
        Dataform = RegisterForm(request.POST)
        if Dataform.is_valid() == True:
            username = Dataform.cleaned_data['username']
            password = Dataform.cleaned_data['password']
            email = Dataform.cleaned_data['email']
            uobj = User.objects.create(username=username, password=password, email=email)
            uobj.set_password(password)
            uobj.save()
            return redirect('loginurl')
        else:
            return render(request, 'accounts/register.html', {'form': Dataform})
    return HttpResponse("User Registered Successfully.")

def loginuser(request):
    form = LoginForm(request.POST if request.method == 'POST' else None)
    if request.method == 'POST' and form.is_valid():
        user = authenticate(
            request,
            username=form.cleaned_data['username'],
            password=form.cleaned_data['password'],
        )
        if user is not None:
            login(request, user=user)
            return redirect('homeurl')
        form.add_error(None, 'The username or password you entered is incorrect.')
    return render(request, 'accounts/login.html', {'form': form})

def logoutuser(request):
    logout(request)
    return redirect('loginurl')