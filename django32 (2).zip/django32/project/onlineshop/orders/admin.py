from django.contrib import admin
from .models import Order, OrderItem


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ('product_name', 'quantity', 'unit_price', 'amount')


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('orderno', 'user', 'status', 'created_at', 'total_amount')
    list_filter = ('status', 'created_at')
    search_fields = ('orderno', 'user__username', 'shipping_name')
    inlines = (OrderItemInline,)
