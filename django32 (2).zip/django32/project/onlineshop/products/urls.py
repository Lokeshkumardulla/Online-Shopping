from django.urls import path

from . import views


urlpatterns = [
    path('home/', views.home, name='homeurl'),
    path('detail/<int:pk>/', views.detailpage, name='detailurl'),
    
]