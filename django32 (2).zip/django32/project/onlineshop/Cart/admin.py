from django.contrib import admin
from .models import Cart, CartItems


class CartItemInline(admin.TabularInline):
    model = CartItems
    extra = 0


@admin.register(Cart)
class CartAdmin(admin.ModelAdmin):
    list_display = ('cartid', 'user')
    inlines = (CartItemInline,)
