from django.db.models import Count, Prefetch
from django.shortcuts import get_object_or_404, render
from django.http import HttpResponseNotAllowed
from django.views.decorators.http import require_GET
from .models import Product, category


@require_GET
def home(request):
    categories = (
        category.objects.annotate(product_count=Count('products'))
        .filter(product_count__gt=0)
        .prefetch_related(
            Prefetch(
                'products',
                queryset=Product.objects.order_by('prdname'),
            )
        )
        .order_by('catname')
    )
    uncategorized_products = Product.objects.filter(
        category__isnull=True
    ).order_by('prdname')
    return render(
        request,
        'products/home.html',
        {
            'categories': categories,
            'uncategorized_products': uncategorized_products,
        },
    )


def detailpage(request, pk):
    if request.method == 'GET':
        prd = get_object_or_404(Product, prodno=pk)
        return render(request, 'products/detail.html', {'product': prd})
    else:
        return HttpResponseNotAllowed(['GET'])

