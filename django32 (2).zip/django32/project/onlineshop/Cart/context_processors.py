from django.db.models import Sum

from .models import CartItems


def cart_item_count(request):
    if not request.user.is_authenticated:
        return {'cart_count': 0}

    count = CartItems.objects.filter(
        cart__user=request.user
    ).aggregate(total=Sum('qty'))['total'] or 0
    return {'cart_count': count}
