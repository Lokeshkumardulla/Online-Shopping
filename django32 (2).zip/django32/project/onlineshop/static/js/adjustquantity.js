const quantityInput = document.querySelector('#qty');
const decreaseButton = document.querySelector('#dec');
const increaseButton = document.querySelector('#inc');

if (quantityInput && decreaseButton && increaseButton) {
    decreaseButton.addEventListener('click', adjustqty);
    increaseButton.addEventListener('click', adjustqty);
}

function adjustqty(event) {
    const quantity = Number.parseInt(quantityInput.value, 10) || 1;
    const minimum = Number.parseInt(quantityInput.min, 10) || 1;
    const maximum = Number.parseInt(quantityInput.max, 10) || 1;

    if (event.currentTarget === decreaseButton) {
        quantityInput.value = Math.max(minimum, quantity - 1);
    } else {
        quantityInput.value = Math.min(maximum, quantity + 1);
    }
    event.preventDefault();
}