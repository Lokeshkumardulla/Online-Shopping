from django.test import TestCase
from django.urls import reverse


class AccountPageTests(TestCase):
    def test_login_page_renders_styled_form_and_register_link(self):
        response = self.client.get(reverse('loginurl'))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'auth-card')
        self.assertContains(response, 'Sign in to your account')
        self.assertContains(response, 'Create an account')
        self.assertContains(response, 'autocomplete="current-password"')

    def test_invalid_login_shows_authentication_error(self):
        response = self.client.post(
            reverse('loginurl'),
            {'username': 'unknown', 'password': 'wrong-password'},
        )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'The username or password you entered is incorrect.')

    def test_register_page_renders_labeled_fields_and_login_link(self):
        response = self.client.get(reverse('registerurl'))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Create your account')
        self.assertContains(response, 'Username:')
        self.assertContains(response, 'Email:')
        self.assertContains(response, 'Sign in')
