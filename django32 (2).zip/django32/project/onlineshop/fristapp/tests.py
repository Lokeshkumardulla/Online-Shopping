from django.test import TestCase


class CalculatorTests(TestCase):
    def test_post_renders_result(self):
        response = self.client.post(
            '/frist/calculator/',
            {'t1': '2', 't2': '3', 'add': 'add'},
        )

        self.assertContains(response, 'Addition: 5')


class MultiplicationTableTests(TestCase):
    def test_invalid_number_displays_error(self):
        response = self.client.post(
            '/frist/mtable/',
            {'number': 'not-a-number'},
        )

        self.assertEqual(response.status_code, 400)
        self.assertContains(response, 'Enter a valid whole number.', status_code=400)
