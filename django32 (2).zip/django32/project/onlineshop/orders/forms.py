from django import forms


class CheckoutForm(forms.Form):
    shipping_name = forms.CharField(max_length=150, label='Full name')
    shipping_phone = forms.CharField(max_length=30, label='Phone number')
    shipping_address = forms.CharField(
        label='Delivery address',
        widget=forms.Textarea(attrs={'rows': 4}),
    )
