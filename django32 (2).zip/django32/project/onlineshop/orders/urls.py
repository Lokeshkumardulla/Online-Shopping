from django.urls import path
from . import views

urlpatterns = [
    path('checkout/', views.CheckoutView.as_view(), name='order_checkout'),
    path('<int:pk>/confirmation/', views.order_confirmation, name='order_confirmation'),
]