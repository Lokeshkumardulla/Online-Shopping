from django.db import models
from django.conf import settings
from django.core.validators import MinValueValidator
from products.models import Product


class Cart(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='cart',
    )
    cartid = models.AutoField(primary_key=True)

    def __str__(self):
        return 'Cart {}'.format(self.cartid)

class CartItems(models.Model):
    cartitemno = models.AutoField(primary_key=True)
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='cart_items',
    )
    qty = models.PositiveIntegerField(default=1, validators=[MinValueValidator(1)])
    cart = models.ForeignKey(
        Cart,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='items',
    )

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=('cart', 'product'),
                name='unique_product_per_cart',
            ),
        ]

    def __str__(self):
        return '{} x {}'.format(self.product or 'Unavailable product', self.qty)